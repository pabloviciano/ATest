//
//  AMac.h
//  AMac
//
//  Created by Pablo Viciano Negre on 16/03/2021.
//

#import <Foundation/Foundation.h>

//! Project version number for AMac.
FOUNDATION_EXPORT double AMacVersionNumber;

//! Project version string for AMac.
FOUNDATION_EXPORT const unsigned char AMacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AMac/PublicHeader.h>


